Files generated for the example of the tutorial (alpha-amylase, 65-atom QM region).
They are written by the scripts of the repository; copy them next to the CP2K inputs only if you
reproduce the example exactly (same tleap output and the same QM selection).

  qm_sel.vmd                 QM selection in VMD syntax (mol2_qmsel.sh -o qm_sel hl_65atoms.mol2)
  type_renaming.dat          atom types renamed for CP2K (prmtop_fix_types.py)
  forceeval_subsys.cp2k.inc  &CELL of the MM system            (vmd_cp2k-qmmm.tcl)
  forceeval_qmmm.cp2k.inc    QM cell, &QM_KIND and &LINK         (vmd_cp2k-qmmm.tcl)
  qmmm-ee.parmed.in          charge correction for electrostatic embedding (vmd_cp2k-qmmm.tcl),
                             run with: parmed -i qmmm-ee.parmed.in  ->  amylase_ee.prmtop
