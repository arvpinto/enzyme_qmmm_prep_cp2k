CP2K inputs of the tutorial, in the order they are run (scripts/run_cp2k.sh runs them in sequence):

  em.inp                 MM minimization (FIST)                       amylase.prmtop, frame_xray.inpcrd
  em-me_gpw.inp          QM/MM minimization, mechanical embedding     amylase.prmtop
  em-ee_gpw.inp          QM/MM minimization, electrostatic embedding  amylase_ee.prmtop
  react_nvt-ee_gpw.inp   QM/MM MD, NVT 300 K, 2 ps                    amylase_ee.prmtop
  smd-nvt-ee_gpw.inp     steered QM/MM MD along the CV, 2 ps          amylase_ee.prmtop

All of them need forceeval_qmmm.cp2k.inc (em.inp needs forceeval_subsys.cp2k.inc instead), written by
scripts/vmd_cp2k-qmmm.tcl. The QM/MM inputs read BASIS_SET, POTENTIAL and MM_POTENTIAL from the data
directory of CP2K (CP2K_DATA_DIR). The example/ folder has the files generated for the example.
