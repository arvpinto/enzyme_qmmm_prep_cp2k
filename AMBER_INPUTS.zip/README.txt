Inputs of Section I and II of the tutorial:

  frame_xray.pdb    solvated alpha-amylase/maltopentaose model (Amber/GLYCAM residue and atom names)
  leap_amyl.in      tleap input: tleap -f leap_amyl.in > leap_amyl.log
                    -> amylase_leap.prmtop, frame_xray.inpcrd
                    then: python3 prmtop_fix_types.py -p amylase_leap.prmtop -o amylase.prmtop
  hl_65atoms.mol2   QM region saved from PyMOL (input of scripts/mol2_qmsel.sh)
